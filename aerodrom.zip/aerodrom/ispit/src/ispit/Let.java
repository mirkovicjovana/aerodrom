package ispit;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the let database table.
 * 
 */
@Entity
@NamedQuery(name="Let.findAll", query="SELECT l FROM Let l")
public class Let implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int letId;

	private String brojLeta;

	private String datumLeta;

	private String vremeLeta;

	//bi-directional many-to-one association to Aerodrom
	@ManyToOne
	@JoinColumn(name="aerodromIdDolazni")
	private Aerodrom aerodrom1;

	//bi-directional many-to-one association to Aerodrom
	@ManyToOne
	@JoinColumn(name="aerodromIdPolazni")
	private Aerodrom aerodrom2;

	public Let() {
	}

	public int getLetId() {
		return this.letId;
	}

	public void setLetId(int letId) {
		this.letId = letId;
	}

	public String getBrojLeta() {
		return this.brojLeta;
	}

	public void setBrojLeta(String brojLeta) {
		this.brojLeta = brojLeta;
	}

	public String getDatumLeta() {
		return this.datumLeta;
	}

	public void setDatumLeta(String datumLeta) {
		this.datumLeta = datumLeta;
	}

	public String getVremeLeta() {
		return this.vremeLeta;
	}

	public void setVremeLeta(String vremeLeta) {
		this.vremeLeta = vremeLeta;
	}

	public Aerodrom getAerodrom1() {
		return this.aerodrom1;
	}

	public void setAerodrom1(Aerodrom aerodrom1) {
		this.aerodrom1 = aerodrom1;
	}

	public Aerodrom getAerodrom2() {
		return this.aerodrom2;
	}

	public void setAerodrom2(Aerodrom aerodrom2) {
		this.aerodrom2 = aerodrom2;
	}

	@Override
	public String toString() {
		return "Let [letId=" + letId + ", brojLeta=" + brojLeta + ", datumLeta=" + datumLeta + ", vremeLeta="
				+ vremeLeta + ", aerodrom1=" + aerodrom1 + ", aerodrom2=" + aerodrom2 + "]";
	}

	
}