package ispit;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;


/**
 * The persistent class for the aerodrom database table.
 * 
 */
@Entity
@NamedQuery(name="Aerodrom.findAll", query="SELECT a FROM Aerodrom a")
public class Aerodrom implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int aerodromId;

	private String grad;

	private String naziv;

	private String skracenica;

	//bi-directional many-to-one association to Let
	@OneToMany(mappedBy="aerodrom1")
	private List<Let> lets1;

	//bi-directional many-to-one association to Let
	@OneToMany(mappedBy="aerodrom2")
	private List<Let> lets2;

	public Aerodrom() {
		this.lets1=new ArrayList<Let>();
		this.lets2=new ArrayList<Let>();
	}

	public int getAerodromId() {
		return this.aerodromId;
	}

	public void setAerodromId(int aerodromId) {
		this.aerodromId = aerodromId;
	}

	public String getGrad() {
		return this.grad;
	}

	public void setGrad(String grad) {
		this.grad = grad;
	}

	public String getNaziv() {
		return this.naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public String getSkracenica() {
		return this.skracenica;
	}

	public void setSkracenica(String skracenica) {
		this.skracenica = skracenica;
	}

	public List<Let> getLets1() {
		return this.lets1;
	}

	public void setLets1(List<Let> lets1) {
		this.lets1 = lets1;
	}

	public Let addLets1(Let lets1) {
		getLets1().add(lets1);
		lets1.setAerodrom1(this);

		return lets1;
	}

	public Let removeLets1(Let lets1) {
		getLets1().remove(lets1);
		lets1.setAerodrom1(null);

		return lets1;
	}

	public List<Let> getLets2() {
		return this.lets2;
	}

	public void setLets2(List<Let> lets2) {
		this.lets2 = lets2;
	}

	public Let addLets2(Let lets2) {
		getLets2().add(lets2);
		lets2.setAerodrom2(this);

		return lets2;
	}

	public Let removeLets2(Let lets2) {
		getLets2().remove(lets2);
		lets2.setAerodrom2(null);

		return lets2;
	}

	@Override
	public String toString() {
		return "Aerodrom [aerodromId=" + aerodromId + ", grad=" + grad + ", naziv=" + naziv + ", skracenica="
				+ skracenica + "]";
	}
	
	

}