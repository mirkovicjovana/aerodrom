package crud;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import ispit.Aerodrom;
import ispit.Let;
import utils.PersistenceUtil;

public class AerodromCrud {
	
	public boolean insertAerodrom(Aerodrom a) {
		EntityManager em=PersistenceUtil.getEntityManager();
		EntityTransaction et=null;
		boolean uspesno=false;
		
		try {
			et=em.getTransaction();
			et.begin();
			
			em.persist(a);
			
			em.flush();
			et.commit();
			uspesno=true;
		} catch (Exception e) {
			e.printStackTrace();
			if(et!=null) {
				et.rollback();
			}
		}finally {
			if(em!=null && em.isOpen()) {
				em.close();
			}
		}
		return uspesno;
	}
	
	public List<Aerodrom> listaAerodroma(){
		List<Aerodrom> aerodromi=new ArrayList<Aerodrom>();
		EntityManager em=PersistenceUtil.getEntityManager();
		String upit="select a from Aerodrom a";
		Query q=em.createQuery(upit);
		aerodromi=q.getResultList();
		em.close();
		return aerodromi;
	}
	
	public boolean brisanjeAerodroma(Aerodrom a) {
		EntityManager em=PersistenceUtil.getEntityManager();
		EntityTransaction et=null;
		boolean uspesno=false;
		
		try {
			et=em.getTransaction();
			et.begin();
			

			List<Let> letovi=null;
			String upit="select l from Let l where l.aerodrom1=:x";
			Query q=em.createQuery(upit);
			q.setParameter("x", a);
			letovi=q.getResultList();
			
			for(Let l:letovi) {
				a.removeLets1(l);
				em.remove(l);
			}
			for(Let l:letovi) {
				a.removeLets2(l);
				em.remove(l);
			}
			a=em.merge(a);
			em.remove(a);
			
			
			em.flush();
			et.commit();
			uspesno=true;
		} catch (Exception e) {
			e.printStackTrace();
			if(et!=null) {
				et.rollback();
			}
		}finally {
			if(em!=null && em.isOpen()) {
				em.close();
			}
		}
		return uspesno;
	}

}
