package crud;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import ispit.Aerodrom;
import ispit.Let;
import utils.PersistenceUtil;

public class LetCrud {
	
	public boolean insertLet(Let l) {
		EntityManager em=PersistenceUtil.getEntityManager();
		EntityTransaction et=null;
		boolean uspesno=false;
		
		try {
			et=em.getTransaction();
			et.begin();
			
			em.persist(l);
			
			em.flush();
			et.commit();
			uspesno=true;
		} catch (Exception e) {
			e.printStackTrace();
			if(et!=null) {
				et.rollback();
			}
		}finally {
			if(em!=null && em.isOpen()) {
				em.close();
			}
		}
		return uspesno;
	}
	
	public List<Let> listaLetova(){
		List<Let> letovi=new ArrayList<Let>();
		EntityManager em=PersistenceUtil.getEntityManager();
		String upit="select l from Let l";
		Query q=em.createQuery(upit);
		letovi=q.getResultList();
		em.close();
		return letovi;
	}


}
