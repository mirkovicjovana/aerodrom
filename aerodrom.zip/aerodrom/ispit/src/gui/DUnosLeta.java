package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import crud.AerodromCrud;
import crud.LetCrud;
import ispit.Aerodrom;
import ispit.Let;

public class DUnosLeta extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField tfBrLeta;
	private JTextField tfVreme;
	private JTextField tfDatum;
	
	private JComboBox<Aerodrom> cbPolazni;
	private JComboBox<Aerodrom> cbDolazni;
	private AerodromCrud ac=new AerodromCrud();
	private LetCrud lc=new LetCrud();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DUnosLeta dialog = new DUnosLeta();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DUnosLeta() {
		setTitle("Unos leta");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblBrojLeta = new JLabel("Broj leta:");
			lblBrojLeta.setBounds(25, 35, 134, 14);
			contentPanel.add(lblBrojLeta);
		}
		{
			tfBrLeta = new JTextField();
			tfBrLeta.setBounds(168, 28, 194, 20);
			contentPanel.add(tfBrLeta);
			tfBrLeta.setColumns(10);
		}
		{
			JLabel lblPolazni = new JLabel("Polazni aerodrom");
			lblPolazni.setBounds(25, 89, 134, 14);
			contentPanel.add(lblPolazni);
		}
		
		this.cbPolazni = new JComboBox<Aerodrom>();
		cbPolazni.setBounds(168, 81, 194, 22);
		contentPanel.add(cbPolazni);
		List<Aerodrom> aerodromi=ac.listaAerodroma();
		for(Aerodrom a:aerodromi) {
			cbPolazni.addItem(a);
		}
		
		JLabel lblDolazni = new JLabel("Dolazni aerodrom");
		lblDolazni.setBounds(25, 138, 134, 14);
		contentPanel.add(lblDolazni);
		
		JComboBox cbDolazni = new JComboBox<Aerodrom>();
		cbDolazni.setBounds(168, 130, 194, 22);
		contentPanel.add(cbDolazni);
		
		//Moglo je i u jednoj for petlji za oba cb 
		List<Aerodrom> aerodromi1=ac.listaAerodroma();
		for(Aerodrom a:aerodromi1) {
			cbDolazni.addItem(a);
		}
		
		JLabel lblVreme = new JLabel("Vreme:");
		lblVreme.setBounds(25, 190, 46, 14);
		contentPanel.add(lblVreme);
		{
			tfVreme = new JTextField();
			tfVreme.setBounds(81, 187, 86, 20);
			contentPanel.add(tfVreme);
			tfVreme.setColumns(10);
		}
		{
			JLabel lblDatum = new JLabel("Datum:");
			lblDatum.setBounds(210, 190, 46, 14);
			contentPanel.add(lblDatum);
		}
		{
			tfDatum = new JTextField();
			tfDatum.setBounds(276, 187, 86, 20);
			contentPanel.add(tfDatum);
			tfDatum.setColumns(10);
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton btnUnesi = new JButton("Unesi");
				btnUnesi.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Let l=new Let();
						String brLeta=tfBrLeta.getText();
						//String brLeta="345";
						//System.out.println("Broj leta je "+brLeta);
						String datum=tfDatum.getText();
						String vreme=tfVreme.getText();
						Aerodrom a1=(Aerodrom) cbPolazni.getSelectedItem();
						Aerodrom a2=(Aerodrom) cbDolazni.getSelectedItem();
						
						l.setBrojLeta(brLeta);
						l.setDatumLeta(datum);
						l.setVremeLeta(vreme);
						l.setAerodrom1(a1);
						l.setAerodrom2(a2);
						
						lc.insertLet(l);
						
					}
				});
				btnUnesi.setActionCommand("OK");
				buttonPane.add(btnUnesi);
				getRootPane().setDefaultButton(btnUnesi);
			}
			{
				JButton btnZatvori = new JButton("Zatvori");
				btnZatvori.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				btnZatvori.setActionCommand("Cancel");
				buttonPane.add(btnZatvori);
			}
		}
	}
}
