package gui;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import ispit.Let;

public class TableModel extends AbstractTableModel {
	
	private List<Let> letovi;
	private String[] kolone= {"Broj leta","Dolazni aerodrom","Vreme"};

	public TableModel(List<Let> letovi) {
		super();
		this.letovi = letovi;
	}

	@Override
	public int getRowCount() {
		return letovi.size();
	}

	@Override
	public int getColumnCount() {
		return 3;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		Let let=letovi.get(rowIndex);
		switch (columnIndex) {
		case 0:
			return let.getBrojLeta();
		case 1:
			return let.getAerodrom2();
		case 2:
			return let.getVremeLeta();
		}
		return null;
	}
	
	@Override
	public String getColumnName(int column) {
		return this.kolone[column];
	}

}
