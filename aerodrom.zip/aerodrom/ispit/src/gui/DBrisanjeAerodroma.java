package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import crud.AerodromCrud;
import ispit.Aerodrom;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DBrisanjeAerodroma extends JDialog {

	private final JPanel contentPanel = new JPanel();
	
	private JComboBox<Aerodrom> cbAerodrom ;
	private AerodromCrud ac=new AerodromCrud();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DBrisanjeAerodroma dialog = new DBrisanjeAerodroma();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DBrisanjeAerodroma() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblIzbor = new JLabel("Izaberite aerodrom");
			lblIzbor.setBounds(65, 32, 123, 14);
			contentPanel.add(lblIzbor);
		}
		{
			this.cbAerodrom = new JComboBox<Aerodrom>();
			cbAerodrom.setBounds(65, 92, 163, 22);
			contentPanel.add(cbAerodrom);
			List<Aerodrom> aerodromi=ac.listaAerodroma();
			for(Aerodrom a:aerodromi) {
				cbAerodrom.addItem(a);
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton btnObrisi = new JButton("Obrisi");
				btnObrisi.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Aerodrom a=(Aerodrom) cbAerodrom.getSelectedItem();
						ac.brisanjeAerodroma(a);
					}
				});
				btnObrisi.setActionCommand("OK");
				buttonPane.add(btnObrisi);
				getRootPane().setDefaultButton(btnObrisi);
			}
			{
				JButton btnZ = new JButton("Zatvori");
				btnZ.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				btnZ.setActionCommand("Cancel");
				buttonPane.add(btnZ);
			}
		}
	}

}
