package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GlavniProzor {

	private JFrame frmLetovi;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GlavniProzor window = new GlavniProzor();
					window.frmLetovi.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GlavniProzor() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmLetovi = new JFrame();
		frmLetovi.setTitle("Letovi");
		frmLetovi.setBounds(100, 100, 450, 300);
		frmLetovi.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLetovi.getContentPane().setLayout(null);
		
		JButton btnUnosAerodroma = new JButton("Unos aerodroma");
		btnUnosAerodroma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DUnosAerodroma dua=new DUnosAerodroma();
				dua.setVisible(true);
			}
		});
		btnUnosAerodroma.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnUnosAerodroma.setBounds(130, 37, 177, 23);
		frmLetovi.getContentPane().add(btnUnosAerodroma);
		
		JButton btnUnosLeta = new JButton("Unos leta");
		btnUnosLeta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DUnosLeta dul=new DUnosLeta();
				dul.setVisible(true);
			}
		});
		btnUnosLeta.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnUnosLeta.setBounds(130, 97, 177, 23);
		frmLetovi.getContentPane().add(btnUnosLeta);
		
		JButton btnBrisanjeAerodroma = new JButton("Brisanje aerodroma");
		btnBrisanjeAerodroma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DBrisanjeAerodroma dba=new DBrisanjeAerodroma();
				dba.setVisible(true);
			}
		});
		btnBrisanjeAerodroma.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnBrisanjeAerodroma.setBounds(130, 150, 177, 23);
		frmLetovi.getContentPane().add(btnBrisanjeAerodroma);
		
		JButton btnPrikazLetova = new JButton("Prikaz letova");
		btnPrikazLetova.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DPrikaz dp=new DPrikaz();
				dp.setVisible(true);
			}
		});
		btnPrikazLetova.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnPrikazLetova.setBounds(130, 208, 177, 23);
		frmLetovi.getContentPane().add(btnPrikazLetova);
	}
}
