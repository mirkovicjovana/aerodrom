package gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import crud.AerodromCrud;
import ispit.Aerodrom;

public class DUnosAerodroma extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField tfNaziv;
	private JTextField tfSkracenica;
	private JTextField tfGrad;
	
	private AerodromCrud ac=new AerodromCrud();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DUnosAerodroma dialog = new DUnosAerodroma();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DUnosAerodroma() {
		setTitle("Unos aerodroma");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNaziv = new JLabel("Naziv");
		lblNaziv.setBounds(59, 35, 46, 14);
		contentPanel.add(lblNaziv);
		
		tfNaziv = new JTextField();
		tfNaziv.setBounds(146, 32, 155, 20);
		contentPanel.add(tfNaziv);
		tfNaziv.setColumns(10);
		
		JLabel lblSkracenica = new JLabel("Skracenica");
		lblSkracenica.setBounds(48, 90, 73, 14);
		contentPanel.add(lblSkracenica);
		
		tfSkracenica = new JTextField();
		tfSkracenica.setBounds(146, 87, 155, 20);
		contentPanel.add(tfSkracenica);
		tfSkracenica.setColumns(10);
		
		JLabel lblGrad = new JLabel("Grad");
		lblGrad.setBounds(59, 154, 46, 14);
		contentPanel.add(lblGrad);
		
		tfGrad = new JTextField();
		tfGrad.setBounds(146, 151, 155, 20);
		contentPanel.add(tfGrad);
		tfGrad.setColumns(10);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton btnUnesi = new JButton("Unesi");
				btnUnesi.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						Aerodrom a=new Aerodrom();
						String naziv=tfNaziv.getText();
						String skracenica=tfSkracenica.getText();
						String grad=tfGrad.getText();
						
						a.setNaziv(naziv);
						a.setSkracenica(skracenica);
						a.setGrad(grad);
						
						ac.insertAerodrom(a);
						
					}
				});
				btnUnesi.setActionCommand("OK");
				buttonPane.add(btnUnesi);
				getRootPane().setDefaultButton(btnUnesi);
			}
			{
				JButton btnZatvori = new JButton("Zatvori");
				btnZatvori.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						setVisible(false);
					}
				});
				btnZatvori.setActionCommand("Cancel");
				buttonPane.add(btnZatvori);
			}
		}
	}
}
